from torchsort.ops import soft_rank, soft_sort
